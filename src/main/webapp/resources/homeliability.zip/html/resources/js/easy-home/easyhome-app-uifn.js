$(document).ready(function(){

	if($("#ef-form-application").length){

		 $('.mobiscroll-date').mobiscroll().date({
	        theme: "mobiscroll",     // Specify theme like: theme: 'ios' or omit setting to use default 
	        mode: "scroller",       // Specify scroller mode like: mode: 'mixed' or omit setting to use default 
	        display: "bubble", // Specify display mode like: display: 'bottom' or omit setting to use default 
	        onClose:function(valueText,inst){
	        	if(inst == "cancel" && $(this).val() == ""){
	        		$(this).parent().removeClass("is-dirty");
	        	}else{
	        		$(this).parent().addClass("is-dirty");
	        	}
	        	return true;
	        }
	    });
		}

	 $(".mdl-select").each(function(){
		var p = $(this);

		$(this).find("select").on('focus',function(){ p.addClass("is-focused"); });

		$(this).find("select").on('blur',function(){ p.removeClass("is-focused"); });

		$(this).find("select").on("change",function(){
			if($(this).find("option:selected").val() != ""){
				p.addClass("is-dirty");
			}else{
				p.removeClass("is-dirty");
			}
			p.removeClass("is-focused");
		});

	});

	 if($("#ef-form-screening").length){

	 	$("input[type='checkbox']").change(function(){
	 		var span = $(this).next();
	 		if($(this).is(":checked")) {
	 			span.text($(this).data("txton"));
	 		}else{
	 			span.text($(this).data("txtoff"));
	 		}
	 	});
	 }

});