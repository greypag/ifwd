$(document).ready(function() {
    $(".selection-inner .item").click(function() {

        changeSelection($(this).parents(".selection-inner").find(".selected"), false);
        changeSelection($(this), true);
    });

    $(".toggle-inner .item").click(function() {
        changeSelection($(this), !$(this).hasClass("selected"));
    });



    var currYear = new Date().getFullYear();

    $('#dob').mobiscroll().date({
        dateOrder: 'ddMyy',
        dateFormat: 'dd-mm-yy',
        display: 'inline',
        showLabel: true,
        mode: 'scroller',
        layout: 'liquid'
    });

    var mh = 0;

    alignChildHeight(".row-eq-height", "> [class^=col-]");



    $(".eh-btn-plan-overview").click(function() {
        $(".step1").fadeOut(function() {
            $(".step2").fadeIn();
        });
    });

    $(".eh-btn-tbl-detail").click(function() {
        $(".eh-plan-tab").hide();
        $(".btn-plan-selector[data-tab='" + $(this).data("tab") + "']").click();

        $(".step2").fadeOut(function() {
            $(".step3, .sticky-help-wrapper").fadeIn(800, function (){
                stickerOffsetTop = $(".sticky-help-wrapper").offset().top;
                console.log("step3 show: ", stickerOffsetTop);
                $(window).scroll();
            });

        });
    });

    $(".btn-plan-selector").click(function() {

        if($(window).width() >= 992) startIntroAni($("." + $(this).data("tab")), 400); // default fadeIn speed 400ms

        $(".btn-plan-selector").removeClass("selected");
        $(this).addClass("selected");
        $(".eh-plan-tab").hide();
        $("." + $(this).data("tab")).fadeIn();
    });

    $(".btn-plan-back").click(function() {
        $(".step3").fadeOut(function() {
            $(".step2").fadeIn();
        });
    });

    $(".sticky-help-wrapper").click(function() {
        $(this).fadeOut();
        $(".step3").fadeOut(function() {
            $("body").scrollTo(".step-option");
            $(".step-option").fadeIn();
        });

    });

    $(".btn-option-select").click(function() {
        $(".step-option").fadeOut(function() {
            $("body").scrollTo(".step3");
            $(".step3, .sticky-help-wrapper").fadeIn();
        });
    });

    $("#btnLoginApply, .plan-detail-desc .btn-apply").click(function (){
        $("#offline-online-modal").modal();
    });

    $("#online-application-btn").click(function (){
        $('#offline-online-modal').modal('hide');
        $('#loginpopup .modal-dialog').addClass('loginpopupext');
        $("#loginpopup .login-info").removeClass("hidden");
        $("#loginpopup").modal();
    });

    $("#offline-application-btn").click(function (){
        $('#offline-online-modal').modal('hide');
        $('#loginpopup .modal-dialog').removeClass('loginpopupext');
        $("#loginpopup .login-info").addClass("hidden");
        $("#loginpopup").modal();
    });

    // $(".plan-selector .plan-opt").sliphover({
    //      target: '.wrapper',
    //      caption: 'data-caption',
    //      backgroundColor: 'rgba(0,0,0,.5)',
    //      duration: 600
    //  });
});

function changeSelection(item, selected) {
    if (selected) {
        item.addClass("selected");
        var img = item.find("img");
        img.prop("src", img.prop("src").replace("_off.png", "_on.png"));
    } else {
        item.each(function() {
            item.removeClass("selected");
            var img = item.find("img");
            img.prop("src", img.prop("src").replace("_on.png", "_off.png"));
        });
    }
}

function alignChildHeight(sel, child) {
    max = 0;
    $(sel).find(child).each(function() {
        c_height = parseInt($(this).height());
        if (c_height > max) {
            max = c_height;
        }
    });
    $(sel).find(child).height(max);
}

$.fn.scrollTo = function(target, options, callback) {
    if (typeof options == 'function' && arguments.length == 2) { callback = options;
        options = target; }
    var settings = $.extend({
        scrollTarget: target,
        offsetTop: 50,
        duration: 500,
        easing: 'swing'
    }, options);
    return this.each(function() {
        var scrollPane = $(this);
        var scrollTarget = (typeof settings.scrollTarget == "number") ? settings.scrollTarget : $(settings.scrollTarget);
        var scrollY = (typeof scrollTarget == "number") ? scrollTarget : scrollTarget.offset().top + scrollPane.scrollTop() - parseInt(settings.offsetTop);
        scrollPane.animate({ scrollTop: scrollY }, parseInt(settings.duration), settings.easing, function() {
            if (typeof callback == 'function') { callback.call(this); }
        });
    });
}

function startIntroAni(tab$, delay, minWidth) {
    minWidth = minWidth || 768;
    if($(document).width() < minWidth) return;

    var bldg$ = tab$.find(".img-building");
    var bed$  = tab$.find(".img-bed");
    var bg$   = tab$.find(".img-bg");

    var bCBorder$ = tab$.find(".img-big-border");
    var bCircle$  = tab$.find(".img-big-circle");
    var cid$      = tab$.find(".img-id");
    var cicu$     = tab$.find(".img-icu");
    var chc$      = tab$.find(".img-hc");
    var c15$      = tab$.find(".img-15");
    var cdb$      = tab$.find(".img-db");
    var cadb$     = tab$.find(".img-adb");

    //prepare
    bCBorder$.fadeTo(1, 0.001);
    [bldg$, bed$, bg$, bCircle$, cid$, cicu$, chc$, c15$, cdb$, cadb$].forEach(function(elem) {
        elem.hide();
    });

    //animation queue
    var qtarget$ = $("body");
    setTimeout(function() {
        qtarget$.queue("myq", function() {
            bed$.fadeIn(250);
            bldg$.delay(200).fadeIn(350, function (){qtarget$.dequeue("myq");});
            bg$.delay(350).fadeIn(350);
        });

        qtarget$.queue("myq", function() {
            bCircle$.show("scale",{}, 250);
            bCBorder$.delay(250).fadeTo(400, 1);

            var smallBall_ani_ms = 250;
            var smallBall_delay_ms = 150;

            chc$ .delay(smallBall_delay_ms*1).show("scale",{easing: 'easeOutBounce'}, smallBall_ani_ms);
            cid$ .delay(smallBall_delay_ms*2).show("scale",{easing: 'easeOutBounce'}, smallBall_ani_ms);
            cicu$.delay(smallBall_delay_ms*3).show("scale",{easing: 'easeOutBounce'}, smallBall_ani_ms);
            c15$ .delay(smallBall_delay_ms*4).show("scale",{easing: 'easeOutBounce'}, smallBall_ani_ms);
            cadb$.delay(smallBall_delay_ms*5).show("scale",{easing: 'easeOutBounce'}, smallBall_ani_ms);
            cdb$ .delay(smallBall_delay_ms*6).show("scale",{easing: 'easeOutBounce'}, smallBall_ani_ms);

            qtarget$.dequeue("myq");
        });

        qtarget$.dequeue("myq");

    }, delay + 250);
}
