var application = application || {};


application.payment = {
	init:function(){
		
	}
};